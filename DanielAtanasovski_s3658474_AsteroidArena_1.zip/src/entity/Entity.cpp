#include "Entity.h"

Entity::Entity(Vector2 position, float rotation)
{
	this->position = position;
	this->rotation = rotation;
}
